function convertTemperature() {
    const temperature = parseFloat(document.getElementById('temperature').value);
    const unit = document.getElementById('unit').value;
    let convertedTemperature;
    let convertedUnit;

    if (isNaN(temperature)) {
        alert('Please enter a valid number');
        return;
    }

    if (unit === 'celsius') {
        convertedTemperature = (temperature * 9/5) + 32;
        convertedUnit = 'Fahrenheit';
    } else if (unit === 'fahrenheit') {
        convertedTemperature = (temperature - 32) * 5/9;
        convertedUnit = 'Celsius';
    } else if (unit === 'kelvin') {
        convertedTemperature = temperature - 273.15;
        convertedUnit = 'Celsius';
    }

    document.getElementById('result').textContent = `${temperature} ${unit.charAt(0).toUpperCase() + unit.slice(1)} is equal to ${convertedTemperature.toFixed(2)} ${convertedUnit}`;
}
